# SIMAD Journal of Management Sciences (SJMS) — Website Prototype

A functional, responsive **front-end website prototype** for the proposed SIMAD Journal of Management Sciences, Faculty of Management Sciences, SIMAD University, Mogadishu, Somalia.

## Quick start

No installation or framework is required.

**Option A: Open locally:** Double-click `index.html`. Some browser security settings may affect local hash navigation, but a normal modern browser generally works.

**Option B: Use a local web server (recommended):**

```bash
cd SJMS_Website_Prototype
python -m http.server 8000
```

Open `http://localhost:8000`.

**Option C: Deploy:** Upload the four core files (`index.html`, `styles.css`, `data.js`, `app.js`) and the `assets` folder to any static hosting service (GitHub Pages, Netlify, Cloudflare Pages, or a standard web host). No server-side build is needed.

## Pages

- Homepage, custom journal hero and disciplinary overview
- Searchable, filterable sample research article listing
- Individual sample article pages
- Journal issue/archive placeholder
- About / aims and scope, distinguishing SJMS from Somali Business Review
- Editorial governance and placeholder roles
- Author guidelines
- Submission workflow and interactive preparation checklist
- Clickable editorial policy library
- Institutional contact details

## Content editing

- **`data.js`** — five research sections, sample article records, draft policy summaries and site identity
- **`app.js`** — navigation, page layouts and client-side interaction
- **`styles.css`** — colors, typography, responsiveness and visuals
- **`index.html`** — entry point and metadata
- **`assets/favicon.svg`** — custom concept favicon; *not* the official university crest

## Important: demonstration, not a live journal

This site does **not** contain published research papers, assigned ISSNs/DOIs, live indexing claims, appointed editors, a manuscript database, user authentication or an operational submission/peer-review service. The sample articles are clearly labeled hypothetical and not citable. Policies are unapproved drafts.

The site must **not** collect real submissions before it is connected to an approved, secure editorial management system. We recommend **Open Journal Systems (OJS)** for the editorial workflow rather than attempting to implement manuscript storage/review in this static prototype.

## Recommended production architecture

1. Confirm SIMAD University institutional approval, journal title, editorial appointments and policy charter.
2. Configure an OJS instance (self-hosted or managed) for manuscripts, peer review and publication.
3. Point the `Submit manuscript` route to the OJS submission process only after actual launch.
4. Populate the public website with verified metadata from OJS, rather than editing fictional demonstration records.
5. Deploy under an approved SIMAD subdomain, with HTTPS, backups, access controls and privacy protections.
6. Create a real editorial contact address and approved copyright/license statements.
7. Register ISSN and article DOIs through appropriate channels after meeting relevant requirements. Do not claim indexing before acceptance.

## Reference approach

The site was informed by the *structure* (not a copied visual design) of:
- Cogent Economics & Finance — https://www.tandfonline.com/journals/oaef20
- Frontiers in Sociology — https://www.frontiersin.org/journals/sociology
- International Journal of Organizational Leadership — https://ijol.cikd.ca/
- Environmental and Sustainability Indicators — https://www.sciencedirect.com/journal/environmental-and-sustainability-indicators
- SIMAD Faculty of Management Sciences — https://fms.simad.edu.so/about-the-faculty/

This concept is an independent sample and does not reproduce those publishers' proprietary interface assets.

## Color palette

- Deep journal green: `#083d33`
- SIMAD-inspired green: `#16824c`
- Light mint: `#f1f7f2`
- Dark text: `#162827`

## Browser support

Modern Chrome, Edge, Firefox and Safari (desktop and mobile). Built with semantic HTML, CSS and vanilla JavaScript; no dependencies. Suitable as an easily editable front-end reference for later integration into OJS or a content management system.
