/* PROTOTYPE CONTENT ONLY. These are not published articles, issues, appointments or policies. */
window.SJMS_DATA = {
  site: {
    title: 'SIMAD Journal of Management Sciences',
    acronym: 'SJMS',
    tagline: 'A scholarly forum for responsible business and management research',
    institution: 'SIMAD University',
    faculty: 'Faculty of Management Sciences',
    launchStatus: 'Proposed journal · Website demonstration'
  },
  sections: [
    {id: 'management', name: 'Business Administration & Management', short: 'Business & Management', icon: 'building', description: 'Strategy, governance, organizational behavior, human resource management, and leadership.'},
    {id: 'finance', name: 'Banking & Finance', short: 'Banking & Finance', icon: 'chart', description: 'Financial institutions, financial inclusion, Islamic finance, fintech, and sustainable finance.'},
    {id: 'logistics', name: 'Procurement & Logistics', short: 'Procurement & Logistics', icon: 'layers', description: 'Supply chains, public procurement, operations, logistics, and resilient distribution systems.'},
    {id: 'innovation', name: 'Entrepreneurship & Innovation', short: 'Entrepreneurship & Innovation', icon: 'lightbulb', description: 'Entrepreneurial ecosystems, SMEs, technology commercialization, and innovation management.'},
    {id: 'marketing', name: 'Digital Marketing', short: 'Digital Marketing', icon: 'cursor', description: 'Consumer behavior, marketing technology, digital platforms, analytics, and e-commerce.'}
  ],
  articles: [
    {id:'digital-financial-inclusion', title:'Digital financial inclusion and small-enterprise resilience in emerging economies: A research agenda', section:'finance', type:'Conceptual research', label:'Illustrative article', keywords:['Digital finance','Financial inclusion','SMEs'], excerpt:'A proposed conceptual examination of how digital financial services, institutional trust, and business capabilities could shape resilience among small enterprises.', abstract:'This illustrative manuscript record demonstrates how an article page could be structured in SJMS. The proposed study considers relationships among digital financial access, entrepreneurial capabilities, institutional trust, and small-enterprise resilience in emerging economies. It outlines possible research questions and directions for mixed-method inquiry. No research was conducted, no findings are asserted, and this record has not been peer reviewed or published.', featured:true},
    {id:'sustainable-supply-chains', title:'Sustainable procurement and supply-chain resilience in resource-constrained settings', section:'logistics', type:'Original research · example', label:'Illustrative article', keywords:['Procurement','Supply chains','Resilience'], excerpt:'A sample research topic exploring procurement transparency, logistics capabilities, and supply continuity in resource-constrained environments.', abstract:'This demonstration record presents a possible research direction on the ways sustainable procurement practices and inter-firm coordination may support supply-chain resilience. The summary is a prototype of an academic abstract, not a report of empirical results. The sample illustrates the journal’s intended coverage of procurement, operations, and logistics.',featured:false},
    {id:'governance-performance', title:'Corporate governance, strategic agility and organizational performance: An integrated framework', section:'management', type:'Conceptual research', label:'Illustrative article', keywords:['Corporate governance','Strategy','Organizational performance'], excerpt:'An illustrative framework linking governance arrangements, managerial decision-making, and strategic adaptability.', abstract:'This hypothetical article proposes an integrated conceptual model connecting corporate governance, strategic agility, and organizational performance. It is included solely to demonstrate site design, navigation, and article metadata presentation. It is not an accepted or published manuscript.', featured:false},
    {id:'social-commerce-trust', title:'Consumer trust in social commerce platforms: Evidence questions for East African markets', section:'marketing', type:'Research agenda', label:'Illustrative article', keywords:['Social commerce','Consumer trust','Digital marketing'], excerpt:'A sample research agenda on perceived risk, trust-building mechanisms, and purchase intention across digital commerce platforms.', abstract:'This example highlights possible research questions on social commerce, digital trust, perceived risk and consumers’ purchase intentions in East African markets. No sample, statistical test, or field result is claimed. The article is fictional and appears only as representative prototype content.', featured:false},
    {id:'entrepreneurial-ecosystems', title:'Entrepreneurial ecosystems and startup growth in fragile contexts: Opportunities for comparative research', section:'innovation', type:'Review proposal', label:'Illustrative article', keywords:['Entrepreneurship','Startups','Institutions'], excerpt:'A hypothetical review topic investigating access to finance, social networks, infrastructure, and entrepreneurial growth.', abstract:'This illustrative record describes a possible structured review of startup ecosystems in fragile and developing contexts, with particular attention to institutions and market access. It exists to demonstrate an example article presentation, and does not represent a completed systematic review.', featured:false},
    {id:'islamic-fintech', title:'Islamic fintech adoption and customer confidence: A proposed multilevel model', section:'finance', type:'Conceptual research', label:'Illustrative article', keywords:['Islamic finance','Fintech','Technology adoption'], excerpt:'A sample model connecting digital service quality, compliance perception, trust, and intention to adopt Islamic fintech.', abstract:'This is a demonstration-only conceptual manuscript record that proposes testing adoption mechanisms for Islamic fintech services. It suggests possible constructs but reports no analysis or findings. The research record and associated metadata are fictional.', featured:false}
  ],
  policies: [
    {id:'review',title:'Peer review',tag:'Editorial quality',body:[
      'Proposed model: a double-anonymous review process for research articles, involving an initial editorial screening and normally two independent subject experts.',
      'Editors should assess fit, originality, ethical compliance and methodological credibility. Reviewer reports should identify major concerns and provide constructive, evidence-based recommendations.',
      'Decisions remain with the handling editor and Editor-in-Chief; reviewers advise but do not independently accept or reject manuscripts.',
      'Editorial conflicts must be managed, and submissions from journal editors or university staff must receive independent handling.'
    ]},
    {id:'ethics',title:'Publication ethics',tag:'Research integrity',body:[
      'Proposed alignment: Committee on Publication Ethics (COPE) principles and internationally recognized standards for transparency in scholarly publishing.',
      'Authors should disclose funding, competing interests, research ethics approval where applicable, and any relevant consent procedures.',
      'Fabrication, falsification, plagiarism, inappropriate image manipulation, citation manipulation, and undisclosed duplicate publication are unacceptable.',
      'The journal should establish documented procedures for complaints, appeals, corrections, expressions of concern, and retractions.'
    ]},
    {id:'open',title:'Open access & copyright',tag:'Author rights',body:[
      'Proposed publishing model: diamond open access, with no charges for readers and no article processing charges for authors, subject to university funding approval.',
      'Recommended licensing: Creative Commons Attribution 4.0 International (CC BY 4.0), with authors retaining copyright and granting the journal the right of first publication.',
      'Copyright, self-archiving, third-party materials and license conditions should be publicly defined before the first submission.'
    ]},
    {id:'ai',title:'AI use & disclosure',tag:'Transparency',body:[
      'Proposed rule: generative AI tools must not be listed as authors. Human authors remain accountable for the integrity and accuracy of every submitted element.',
      'Substantive AI assistance in drafting, analysis, figures or translation should be appropriately disclosed in accordance with the finalized journal policy.',
      'Editors and reviewers must not upload confidential submissions to unapproved AI services. Any permitted AI assistance must preserve confidentiality and peer-review integrity.'
    ]},
    {id:'data',title:'Data availability & reproducibility',tag:'Research transparency',body:[
      'Research articles should include a data availability statement describing how supporting data and materials may be accessed, or why sharing is restricted.',
      'Where lawful and ethical, authors should provide research instruments, code, protocols and anonymized datasets in recognized repositories.',
      'The journal should document procedures for corrections to published records, reproducibility queries and data-access concerns.'
    ]}
  ]
};
